package com.tandev.musichub.model.playlist;

import com.tandev.musichub.model.chart.chart_home.Items;

import java.util.ArrayList;

public class SongPlaylist {
    private ArrayList<Items> items;


    public ArrayList<Items> getItems() {
        return items;
    }

    public void setItems(ArrayList<Items> items) {
        this.items = items;
    }

}
