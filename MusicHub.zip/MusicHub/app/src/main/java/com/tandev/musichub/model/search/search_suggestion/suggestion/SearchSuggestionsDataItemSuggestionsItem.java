package com.tandev.musichub.model.search.search_suggestion.suggestion;

import com.tandev.musichub.model.search.search_suggestion.SearchSuggestionsDataItem;

public interface SearchSuggestionsDataItemSuggestionsItem extends SearchSuggestionsDataItem {
}
