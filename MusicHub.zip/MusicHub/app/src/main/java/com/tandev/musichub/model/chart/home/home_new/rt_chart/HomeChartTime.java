package com.tandev.musichub.model.chart.home.home_new.rt_chart;

import java.io.Serializable;

public class HomeChartTime implements Serializable {
    private String hour;

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }
}
