package com.tandev.musichub.model.chart.home.home_new.item;

public interface HomeDataItem {
}
