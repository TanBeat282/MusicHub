package com.tandev.musichub.helper.ui;

public interface PlayingStatusUpdater {
    void updatePlayingStatus(String currentEncodeId);
}
