package com.tandev.musichub.model.search.search_suggestion;

public interface SearchSuggestionsDataItem {

}
