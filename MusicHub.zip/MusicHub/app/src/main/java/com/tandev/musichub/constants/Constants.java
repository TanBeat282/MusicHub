package com.tandev.musichub.constants;

public class Constants {
    public static final String VERSION = "1.10.34";
    public static final String SECRET_KEY = "acOrvUS15XRW2o9JksiK1KgQ6Vbds8ZW";
    public static final String API_KEY = "X5BM3w8N7MKozC0B85o4KMlzLZKhV00y";
    public static final String COOKIE = "zmp3_app_version.1=11034; " +
            "_zlang=vn; " +
            "zpsid=eMqpTcwdFagwSov_G9foCj0GV6b5cN4uqWrwTHQ3266D3GTG6FyDMV0kT6iOeIDSZb5MMdw4B5IDKLbKV9WmM-SMTbaJc71ewLWtVGofNsZxV35PDqWq; " +
            "__zi=3000.S8FWvuaKLjLhdQ_xpqeIq6YUfVc0I1VKB9sg-OfE6zOvDm.1; " +
            "zmp3_sid=hv6hSi8eL4UvbAXno2f9GQN7iWYHTKayWCdE3Qa8Qa-xoP0Zh7OLROgljIoaTHLYXAsfCAiVKas9mgbmc14S3AtTc5-O0pWAYR-_E-bE7KwPcg4YP0; " +
            "_zabst=1%2CYWR0aW1hLXN0YXRpYy56YXNjZG4ubWUsd2ViLmFwaS5hZHRpbWFzZXJ2ZXIudm4%3D%2C0%2CzpmLx4SOwQDM0IjLiV2d; " +
            "atmpv=3; " +
            "zmp3_rqid=MHwxNC4xOTEdUngOTmUsICdUngODN8djEdUngMTAdUngMzR8MTmUsICxODI4MTU3MzMxMw";
    public static final String URL_IMAGE_DEFAULT = "https://photo-resize-zmp3.zmdcdn.me/w240_r1x1_jpeg/cover/3/2/a/3/32a35f4d26ee56366397c09953f6c269.jpg";
    public static final String TAG = ">>>>>>>>>>>>>>>>>>>>";
}
