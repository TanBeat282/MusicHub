package com.tandev.musichub.model.hub;

public interface HubSection {
}
