package com.tandev.musichub.model.artist;

public interface SectionArtist {
}
