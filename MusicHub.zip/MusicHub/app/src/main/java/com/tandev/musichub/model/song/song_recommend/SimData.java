package com.tandev.musichub.model.song.song_recommend;

import java.io.Serializable;

public class SimData implements Serializable {
    private int v;

    public int getV() {
        return v;
    }

    public void setV(int v) {
        this.v = v;
    }
}
