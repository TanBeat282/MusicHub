package com.tandev.musichub.model.top100;

import java.io.Serializable;

public class GenreTop100 implements Serializable {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
